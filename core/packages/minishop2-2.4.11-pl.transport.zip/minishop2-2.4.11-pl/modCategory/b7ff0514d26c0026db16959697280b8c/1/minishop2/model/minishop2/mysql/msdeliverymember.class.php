<?php
require_once (dirname(dirname(__FILE__)) . '/msdeliverymember.class.php');
class msDeliveryMember_mysql extends msDeliveryMember {}