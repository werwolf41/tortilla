<?php
require_once (dirname(dirname(__FILE__)) . '/mscategoryoption.class.php');
class msCategoryOption_mysql extends msCategoryOption {}