<?php
require_once (dirname(dirname(__FILE__)) . '/msoption.class.php');
class msOption_mysql extends msOption {}