<?php
require_once (dirname(dirname(__FILE__)) . '/ecthread.class.php');
class ecThread_mysql extends ecThread {}