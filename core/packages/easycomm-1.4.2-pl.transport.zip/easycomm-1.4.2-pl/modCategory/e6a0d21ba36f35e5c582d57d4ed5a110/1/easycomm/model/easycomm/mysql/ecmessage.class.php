<?php
require_once (dirname(dirname(__FILE__)) . '/ecmessage.class.php');
class ecMessage_mysql extends ecMessage {}