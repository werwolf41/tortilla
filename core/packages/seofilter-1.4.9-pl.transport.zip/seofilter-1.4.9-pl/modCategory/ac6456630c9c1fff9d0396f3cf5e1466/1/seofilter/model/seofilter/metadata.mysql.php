<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sfParam',
    1 => 'sfPiece',
    2 => 'sfPieceContent',
    3 => 'sfDefaultContent',
  ),
);