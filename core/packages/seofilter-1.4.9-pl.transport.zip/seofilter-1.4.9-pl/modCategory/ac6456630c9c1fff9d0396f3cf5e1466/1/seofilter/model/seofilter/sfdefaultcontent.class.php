<?php
class sfDefaultContent extends xPDOSimpleObject {}