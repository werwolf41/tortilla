<?php
require_once (dirname(dirname(__FILE__)) . '/sfpiececontent.class.php');
class sfPieceContent_mysql extends sfPieceContent {}