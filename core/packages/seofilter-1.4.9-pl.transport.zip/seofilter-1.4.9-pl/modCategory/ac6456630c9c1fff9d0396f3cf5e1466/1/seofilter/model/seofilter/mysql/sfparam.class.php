<?php
require_once (dirname(dirname(__FILE__)) . '/sfparam.class.php');
class sfParam_mysql extends sfParam {}