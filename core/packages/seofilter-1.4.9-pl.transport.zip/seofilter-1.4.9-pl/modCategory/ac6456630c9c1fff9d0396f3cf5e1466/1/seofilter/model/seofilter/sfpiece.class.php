<?php
class sfPiece extends xPDOSimpleObject {}