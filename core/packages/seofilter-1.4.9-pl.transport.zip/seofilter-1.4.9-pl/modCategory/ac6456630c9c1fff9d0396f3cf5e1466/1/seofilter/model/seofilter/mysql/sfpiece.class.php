<?php
require_once (dirname(dirname(__FILE__)) . '/sfpiece.class.php');
class sfPiece_mysql extends sfPiece {}