<?php
class sfPieceContent extends xPDOSimpleObject {}