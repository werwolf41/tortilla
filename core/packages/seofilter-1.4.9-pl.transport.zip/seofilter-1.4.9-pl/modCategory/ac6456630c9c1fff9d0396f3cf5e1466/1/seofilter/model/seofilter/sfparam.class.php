<?php
class sfParam extends xPDOSimpleObject {}