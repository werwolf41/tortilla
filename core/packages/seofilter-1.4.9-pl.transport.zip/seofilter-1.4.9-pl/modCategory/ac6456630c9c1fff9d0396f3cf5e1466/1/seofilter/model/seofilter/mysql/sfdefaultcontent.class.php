<?php
require_once (dirname(dirname(__FILE__)) . '/sfdefaultcontent.class.php');
class sfDefaultContent_mysql extends sfDefaultContent {}