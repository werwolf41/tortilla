<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '966f5d002e0eacf2001e2e9a8edc788d',
      'native_key' => 'core',
      'filename' => 'modNamespace/c354eb09266d08bf665f8481c39e53eb.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '1a5d7e078c32a66c3b9d4489c2bb07cf',
      'native_key' => 1,
      'filename' => 'modWorkspace/130707a699c8f953c21f76ab11e1bb84.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '6707ca2dba9b9dca03da48acadbaa693',
      'native_key' => 1,
      'filename' => 'modTransportProvider/7c1943485909551279a4837f76cd1961.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f6c08dd2649c01d45aba2214f1327fe0',
      'native_key' => 'topnav',
      'filename' => 'modMenu/c0428b6f0832e9a06459439106cfe5ac.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b9a19a100cee8c1a7a7a4979a5286dcc',
      'native_key' => 'usernav',
      'filename' => 'modMenu/80b6e3e60e36476c779dca9c377ee265.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'aa9cc1ce69586e96a4b1291843dc7fdc',
      'native_key' => 1,
      'filename' => 'modContentType/21550007233810ccde9ddbd5df12e7fd.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '20606ab9749a39fd55b6d426f16638e1',
      'native_key' => 2,
      'filename' => 'modContentType/1d5e78795b9f7f99ce9aa03afa9adea1.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '93efb419a3ab521f453d9dc3d9c50ea8',
      'native_key' => 3,
      'filename' => 'modContentType/9204c40127fbaee0b1e23a3044211388.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7d26f4d97dfe3ebc18345c449cabc47d',
      'native_key' => 4,
      'filename' => 'modContentType/1c28bca393f9871da3c0403be4c54d96.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e18498532514798ddb6edb5df550811d',
      'native_key' => 5,
      'filename' => 'modContentType/82e6c0f8306b607b09aac8d633ca9ff5.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3a455a431c5ca7194fb67e39093746c6',
      'native_key' => 6,
      'filename' => 'modContentType/1c38743142540a31faa4c7509d8a12c1.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd0cacc3c41f13470e0789781dcf6e7fc',
      'native_key' => 7,
      'filename' => 'modContentType/bfa4e54a8cd054cb032911b9d2f5b59c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '187c5626597ea5e8bcdc296055e40d42',
      'native_key' => 8,
      'filename' => 'modContentType/d0089f0774c3489635d4761ae6d8663b.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7b8b4163ffe957d66093178990c37118',
      'native_key' => NULL,
      'filename' => 'modClassMap/7cf8fe3f6210d026af76733899a71b1f.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '45d2fe31291d8f5e1a6aff60d91283e4',
      'native_key' => NULL,
      'filename' => 'modClassMap/49863d54f4cf2022772ddae2d2b5953e.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'dd33053bdf23da606267ed13d0306f5e',
      'native_key' => NULL,
      'filename' => 'modClassMap/60137e1445bea54e85242e2191bdfadf.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '91b8b0689bea037c5a7c09b68191dedc',
      'native_key' => NULL,
      'filename' => 'modClassMap/7f2ac09fbb839191b6119adaf90c3dab.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cc7629fcad9017ba6b44fe3a204ccd0b',
      'native_key' => NULL,
      'filename' => 'modClassMap/84ec46e19c8655e3683dbe9ddc34405e.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9ca8442803d632a962f19d65902975e1',
      'native_key' => NULL,
      'filename' => 'modClassMap/87cc9c89c9df283f95f9abfc76265f7c.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a52bc445e22d62105d40af16a47295a7',
      'native_key' => NULL,
      'filename' => 'modClassMap/70619dda91bb232d7c7724984be50cc2.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4c921d3e2c886cd0e5aaa3946625ef58',
      'native_key' => NULL,
      'filename' => 'modClassMap/ba92084a533760853e01445cb21e17df.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '09cbb52eaacd341d2db969bddd3cd380',
      'native_key' => NULL,
      'filename' => 'modClassMap/d2f98f0d0036cea52c50b8f917757865.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90a8487c1e8af2107f7bddb1ed543081',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/b4d85c6d5fa2fb3bf7875c95e068301e.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da03609ffdf58fed0bdaa2a14b510fcc',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/14d7a251c852ddd51c6fe76606d2b4a2.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eee91990756d2f3212f5ac2def58fd68',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/110172f921d23f7d1a635efcba6fc297.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e982abb141159c0bc8fae1eda23b65fe',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/d5b87e164ca128dd4d8396ad8c3f12cc.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa21efb30e192c69504e7f5ffd78b19d',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/13cfbd9fa974f921edaf81613b14029c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c4118f0ac8cf60555434a73fe9246c9',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/a0163ca7ce37e61c5a64fbb984ba4364.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbdf0caadfb1e65075cac56c43b90bc0',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/5a5c6f8c320c0e8c7cc2ce9254efa5a3.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27f00a849f789252e852317e072ba904',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/b9474b703533069fe521c91aeb0b2785.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a122717df21e24a2ad887b16de51f0d',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/c2bbba65f024bab5d0fc68df5dd2f871.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59a486ca3d2640cd7a50368bf92aa802',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/cb81d692e88ddbf848828ab8338f27a3.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '613873ed53481402a701a1ddc3488317',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/f9321081e1ff38cca7eb28a47e92fb50.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f2d7f7a6803c6911366a36cca790b7e',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/a851ba8b456b782c47dc6bb70eb5327a.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd082aec9e07bbe1683e3738321edc265',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/62e3b219626b5178609162fa67dbc68e.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55820357fb85fbaf7e5a69ed513317db',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/43b2e9b94827ada7f3234a35b5a45a3f.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f247207879f8cd81f407494a4eeeda5a',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/cef1c3f0dc08fa3fc2f8464117a594fd.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d8fd3263024ba06349134031284f46f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/7eadfe75b23c53517daf67d8de988622.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da08f9e7d6d2db29b1076ec5a818d090',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/9d1cc403315a673685321f0f152bd031.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdd679ba71cde00a4d055aa2cc84a324',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/3e3e6aa81cf82a9c5bfe3cba4270c86d.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d51e66d958bf34aec4c5abf4dc64d17',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/0eb0eb9bb24f2f84f394a8b0932eea5e.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74f6658f383d896b545b71e91e2b9fc1',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/8cd22bfe4d89fd5d3c9263b472c5209a.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5700633995eb1eb19f9906ca8135abce',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/9bd265ffd18b5b77e7870384331ac591.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ff0da136c995ce4b66e55a3f702c009',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/53653d3232992457a1181a6e4db51f05.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5260563d6a1442bcdc403c04e8c5f5b6',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/e158023cf5c02b59d1fbb00b37b411a1.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a8d1cf0209f6b175f970e5b0d66cf80',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/63b17995b016d5a733d297473b82ed1a.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35fdc46bb704a964a5fd86e6aad0ec5b',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/846b48e13138da467e8274f209db994d.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce44d3c7266e03afc026493366f2d210',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/48effeee1da41759d5fb64af488e3209.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff37e5eaed3df3675d60ad6d55e9c694',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/66f14be2c8462e9610268bd96cddc0b1.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd46e1a94a49efe9ba9b9bc8164955c7e',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/8d603d35e7dd3af262bb7c559e4f432a.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f76df75c025ac6cce26e986f2c37654',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/cf5ec9158e03a71d428482f286d4b73a.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38996ffdd84a963f4e3acfe7e9db285f',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/017d4af025ce02dd77625c84e9a8b1d2.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be82273dff437a0bcca24ac861f719be',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/47ae1db6d1a85f3f85bdc2f373156edd.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c669815f8d37825c63ace04d0a1d4bac',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/cfcb888326e7ada2cbd7a631e226c99d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3afa55272a8970e9a595cae49dd2b6b4',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/0bb2d17de30aaac4c4a8a309e8742b7b.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c84a556eab509c74c72978bf16e32e4',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/5bd939175149f86926f4e82aaa1d81be.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8d88f727b1ea7d6887c3cbd4e60eedd',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/bd97d336fcd409e0173d4c171496fd4b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2119e53af494d1e503b23a307f256b42',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/ff3059a64d5f3a626bc21404b0c1c88c.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4aefa962877a5af8d10658399e2d4415',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/c67be874299d994b72fea6dd6f396316.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceaf86e72d0783dd397fdf4af1b62275',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/541aec2ab16ced08b148868538bbaecf.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3ddacf96ae3b9a99a8789fb1e28079d',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/7ae519e5294d8bb6a11af758c5a8cc57.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d24406b25fad109c150cf34758b7a82',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/5baa9115e9ffe990290bc538df977be0.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '706d1b6c8989b89527f055a9b176fe1b',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/061ac712e84ed844a80542c09ea2d9b6.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efed597d9fbf43f22db9a8a171dde98b',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2f25b4a8d03ec98de53498f7eeeeeca5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1b8ea6a55734d5c2075ead0ed9f0b27',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/58831a68f7fe118ca211b351ee300434.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c3c99ba0818e719750b850b600440ce',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/1ea7bfd5286fd06443cd355a6e8784b3.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '789227833b04594c1a8055448abcd6ba',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/965565f1d981873282c4cd1ea4643a95.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ac46ddc80e9cef5f5a59c3c1869778f',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/b7b98d53e16d9a30f6c889b7be2f850f.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d23c61417a9d48812c8fea763dd6204',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/7fcd9b5b63efe30a794a879acb7c532d.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6173abdbc17ce2d316b1b4cad2c41a3b',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/ead5a054261013b2d3600ab5f13f1525.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd1ba455982f891a2e04efec95507e17',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c60c9588392044417982913a3ac94c3b.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67a981d20092304d665d79cb526ece31',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/9c682f01cab29aed94e4a946a2ebe641.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce243cff2e20604930fb9ac686609caa',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/6e270bf3d47989b1a76456ff06929b79.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42d19cee56477931771a73a6caec3c12',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/286bbd8745697c8c280fbcabdcd687c3.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '170c76421d5c6bd578ac6b25576b6fd4',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/585583a3c9d7facfc51ea8a8799f5127.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72b58cc3158b39ae2fe7273549159581',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/0fb0ac6914dfacd0b348794f9d5ac635.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b30dfd2a8bdae5d86606d832ef0482f2',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/3a52803f5a22466f32674c19e5baf232.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2398dadee601c586b747214ba5ac809e',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/cb44eb245009773da73ec6e740e5b0df.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8468123627ee63de867ff46c59f32989',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/28d62fb7c61361cd20d23bf37796c215.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0884103c28bac03d5e9ce97f7752eab4',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/944b0a926f11678f429ad094b65cfdb0.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51b9f30eaa4f616617af3c41747e68b7',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/ed0f9f072dc3a8694d4c8a95c3f275c8.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1412cf47f8e1bd789a74191aed45738',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/7171bb4a1e9d79ba7dd6bf01ed729412.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd51dfa3b2796a32e1a103f04bdd9ded9',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a950605f3ddc0b20820170b01d5785de.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32653ce07a2eb3ef5b310aa5710e38ed',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/c408693a687c68337bbc1b367af5ba82.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfee8fd7822b423c89f75c93b1e97821',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/5fbdf7b8529b129515de2204049b07c6.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e80a54ead56729488835a57634d68982',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/d19c80aabbc5f1a5e914637673b1ca6f.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33c6a8e184f0c7028cea2b1390868bed',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/a91b6c94f024416cdaf61f0a4efc7dca.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1a32e5b4e938b00fbb242b8b3f2fca8',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/4f7218225a2dbe885128a08893f39e59.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64783dc7c323ae5c209991263d408e3e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/65741f7ace8ac876e8b7cca848649f8a.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a07fc8405cd06f1f7c0dfc84ac7a3fc',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/854edce616bd5258da74e29d9242a7d6.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b6cf2da14aa3ddc4bd4b0083c9906c2',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/e444fa13fbcf3e55b4c29610032ad63c.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6e13e0350d13812bdce886554fb2d0a',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/3457c260d004e188a15bbc9c13867f58.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e706f6aa25534e858f11a88d68d2ed9',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/0b9a129614766298a94fd19fe3b754c2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8404c504e22bd0b3746ab92f89fd807e',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/1f0a9ae0a8234f7233cab13c79f4fda0.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10a9e4df962cfaa4870d9638c7a3c4a4',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/2e1654c063476eb1ed06a56cd1b6ee5c.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb74645a5d060695ccec781b62073c1',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/e6682a6baf022a3c49a396a2332512c6.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '106c374ba0053143af73cf8b863ae9a1',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/463980b6bac0c55d8a1c2712b678ce5d.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb2a9097ed4216d9091baa951b21ac13',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/153f1874a3db5bbf78b80a0de0a9b51b.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9472045e6e3a739d388f9deaaf2fa5b1',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/0b7d3e88b02def243acb3f306da2c4c9.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6dd31ff03cfba0dc709f20d89337899',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/71f5016d8c53fb82dc75115cf8a49ef6.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c390014759e4d9c0704aa1e9d9e06716',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/cd895073b3348eeaa701103bb8cee3da.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e949c4304b416c1d80a32a70a1bbba46',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/768d2a746b474439df61504ffe6f5531.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cc67ddef40977b15a225f70d38887ee',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5519b93261758969fb75658685ab4b5f.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81111cca7b0ea752717552af905de5da',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/f463392c36920c4a32dfd0460de23f85.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6ef90a9c2551e7835dcea4c64d02e44',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/38399a541d03005bddc6faae6beebed8.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de070a60a81c6fbccacead29d2b00f90',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/f9b64b93a6cf64ecd0f41a4ecff19031.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52f71381379ac155b5cb9da65a120f6f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/c6cf5a8dae48a6d92671c07de4ef69a6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '687116dae8a50e8c5d7e03122e88dbaa',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/0c43537c9aace99c1fcd3f0f75dd6e20.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '647402facd7311a7931a13c34d6cf3b7',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/8f3ec1021bce2ef903fe289ee4557224.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39522263f4b16d2134d3b1df61931629',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/d1c9b0158f29bd478778a8e446aeac64.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dec942edfa5b99d5e8e3bae024281979',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/08f27b4a8c8ee2f176f63f6a05a48fb8.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81125cb102fb2f749a7982f56ee0b35e',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/bad4f7a860799ffcb5ee214912b2fda8.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5513298bd46c00c9d56a3e1069d26e6',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/615d697e398958bca8a1362e7a9eb3ca.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd070dc44d6bdb959f07e7638da47e16',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/3376037785bd1a6f4f4f90249bda9d05.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86183b7d9d9160590cd7b86a52b49b03',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/050ec07e2f4c12d0e8bb27193d913f8b.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4522ecdca6f61399214c93330856b4a',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/3f4d90be32254f58ffc65ff5bd2848e8.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2df79c42db51d334333f72b38bc2cc4',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/5d946fd0e8a92eca9bff6029a8e37f8c.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40dc5b17cbffdadeda6a9e91df3d8f62',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/cfd0303c689ed524636d76c6616b054c.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '406b32374c8321315f9c86eb744ba468',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/5207544a460b5c02c165d9cfac067c29.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '088707e7f5a1fcccbc1266e36aa547ba',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/1704f6e0eabc03125d496a12b901b865.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16199c31d1982b7a5972a10eaa5eb257',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/82448768e056b349c23ca1ab96b228f2.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddcb35342cf432a48f6beda869a9e649',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/a48c0dc14014a089308bf8e9b90dc777.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0532cdd8281f7162cc615450a89c68b',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/b47b65957c0414fa2ff3e5dc5c12faf2.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e27c079b35b260cba967511f364aab9',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/c0e9795d66dbe8c68be12b56ba1e5102.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cbcfe30301d32383132ecd709640a2d',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/5ba9346479a9542300871b3b9f53a1b8.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b94a1f21cf4bee62f3c84438aef2989d',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/2c1e9629c602129ed1a0738a57afbc4c.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f9d97b9dcc82863ccbad539e4e9d3d8',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a649bb2e658f4c5c8b792b55f8ba59c9.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0354402c0c310a77ae6aa7c7eac300f',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/26407c8a6f37cd1217f6e899bea609f2.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc7287aa414303244c02b510698c2f2b',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/08548990d1d6e59266bedb264f99a5ff.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '410cb395418a61d3c8d285dfba038d4a',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/de044c29d1a5f78dbb9c2f9d5f1d8a65.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d0f59700e1ff0f1a86262211100717c',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/251b4c15624d453bad28132ad122dacc.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5da78b956c376dd18eea3acc2d2fa936',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/535d3bf816cbbe2beb2070f5176c5280.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fcc2b525eeee04ab8163feb33ee99a5',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/49e4dbe1a512a66b60ed63d95e458ca4.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72b5391cb4e0b03307b8e149ace96fb3',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/842371061fc48294b4de8025ab776725.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd335a9c06af1025e50331b3f4fd1a5a1',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/a781f6f8117e50bb76fefeaf8268bbfc.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac22922a922e35badd678c7cef9bb55d',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/36560d948e34fda03d1ac5c6a6c98ad3.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '737b9dc251c918d00de5c8140128a9d3',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/c6dee686bbddfd9c5e6ba2106863829c.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f9c454ed857fcd113fa86d0aed89666',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/3fd635b6108ffc2f0ed4187cc027610c.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a42ad18fcf09d7698ab797a15e78d20',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/ccc64f0951f7364919bf1c3bb3faad1c.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2dbf94d6da5572e1671c73a8bcf2a37',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/3ff4a006a455e7d58198cedf373ed2fb.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34d6066274f251824b2916bd22138cd2',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/e03fad7f1ef50ec65928c8c6fb0e2bf6.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17ff76f677bd63fc58531c8aaab0cfe4',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/4e523471e24b0216240d2dd1fbb511b5.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99a7fbdba499c25c6c116c10c760b199',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/e973de573f60d61220afd19f239364bd.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b49177ac2a607d7457aac4951913d422',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/6f747687c84f425eb7257a7468a86c38.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eada3afc5b82bb80b261ad8c94e6f05',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/9b132f9b23ee63e18cc4d7ca964ffa58.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0363adba22e7530b7c5fcf935f34f99d',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/5c78cfa5d8d8185dc1240639f0849888.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36aec31d31d5067972aa180479accdea',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/7653307b69f2ec2575a208dce9d02eba.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc081a47db739f9a857e4a9a4af6d552',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/16f9e0ef7f7532dab65fa8032e51c179.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a48562be3e2de934fadcd712f7aafb7',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/570a9adb5625ba53725c8597bbfc9572.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd53a1bc391d74d0e2c3fbc5897fc8237',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/9f92ff4bd9ea70c105739e4db07f7f4f.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b808e7b57ce388d4f22b36f3f6e921a',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/b22d57ba1dec081909ec67e3024fd699.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac803f622f77e0939aa41688c994ca4d',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/4883f5549fa9a1469a1129956ac50b3b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15598d87d3a07bddc7e1deb9225ea5d6',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/23a3d930e547b1d6a2a2096a400622fb.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f81772269041af92e25d1672a48ff3f',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/af36ed16b82512817041578102c85cca.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98bea0f0413c66874a17b907d1a916c5',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/ffa86d073d68caf7abbbea47aefda935.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0ba1dc3c68842ad020d545c952762f4',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/1ea9a6480c6b1264a47c95b1cd828535.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac749c2ae42fef8d7fcd7017359a4e56',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/c446668cc38a9535c651c18ca947154e.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '629dd10409f1acb253fad1905d0ed412',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/fdc0e67ea666fe99acbabf6be12032af.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea7543812a8ad4730e390c192a7a8c01',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/6b690034cc9990f0e5c5e6ffd8f28da5.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f68a67717d38df67653e9ad3b000704',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/179cbefc2c622d2bd38c2e892396da64.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e6fe05df58181cce3f3b0e8f277bba4',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/c3b6b8a9eb46b75b04e9522e1fd1f58a.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e0aa50947a8eabc25ac3657cd48e633',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/d38d82cdf26987486e77a3132c5912d3.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b66733945caf86869f6201c8f66b7596',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/bc9e934953cf0f567d0f009cace735c7.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfd99d173d26a91fa4fa575400959946',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/3a90051ae1d3bfb0d9cc7882ca5558fc.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d83a074bc4659a7268d003cd088ec7a',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/98bba0c7da1150889f63e44a0218f42e.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6393ba55a4b860cb30e14317f9fa48f9',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/16572b21775f5d744b88df47ea685a26.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '956cd40836e268904c512a14986c1b4f',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ec51dbf6cd7a77167ab88600d411a14b.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30e2d6dd609b4ad13ea58f5acc218dd7',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/83662c979c25dcaf8e1447dbabe24710.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '481165effed7b27dd892eac11b01c0e0',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/0efa7ef41074e436d33dd98e8277580b.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d43ae4fd0be5820601410dbca357685',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/bf415e3411202777a9153b55a7ed7dcd.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d7945bcf64785df1d9e8ffb8065af65',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/7db2ea1f24ce2accfe3fbea40385caf9.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16719cc697bd57536adeae7acdfe826b',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/6d62e01dcd96cc03bce6ebce14749b3c.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ae0ec9233a43ec65c09e16d59f80ce6',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/84ff3f39d8a3caf35784c9d4ac4993ba.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c12f6a9116cd5b0ff8cff7a60b4b643',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/36058d3789f4a34ce0a19657ef45fb3a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6a15bf213d6be7a9f1ac92ff8592c6e',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/0a99e458bc0c4c036242cd303f153ddf.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93681189ea243986f544b5e4af68816e',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/39bb0ba2bc3bf23fae181e41830af1ec.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64f78b2d33e6c350b028c392b7e9d7e2',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/318fecf45315c3eb47fe5ef70f7b10a2.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1acd6bb0df6426040200dad7bf30190',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e2b63c7f996efa4a76f590bafe6c3ad6.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66937f20bb6e7d0a3b3242dc1bcaac77',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/b72aa40f602e433d37be21d9e89047ea.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0652cfaa318bdfe2eba0772be6d53ee',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/d957de1571465924e47df709c66bf778.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46fca30cc17a4c41684d51efdc17098c',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/5d1a42cab08555cd965d23c9c3c19b9a.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27576d77f41d43c52a8229752389b5fa',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/b8f2d51b2a9694209623040c54657e6f.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f07f39e03fa878946d5b935d317aecf',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/6d1858c7c21c701feaf55b50b53b3fd2.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f94e0a6dbdf8f62e2c20a55ec34fe3f',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/8ceef179f914383901cd6c51bdde6e37.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc4892ad787f39a2b4fa30a982e33138',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/01ee7214e3598f34976faa4ab75c6f8d.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b1f5c0d6503b5360cb07d25b314b409',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/b17ffad486c97395e1c7badc25a369f0.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3eeec0a3de7de86d587e8a82e8027bda',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/948104140c6fafd88bec999319f76791.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c850c5fb6141588ba1a5f1a5a4a054a5',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/a5a29cea1f860a89be35a4b59119f71c.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ed769247f8a4a6544cac65fbc7dc638',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/b57d0fabc1f8b77e2f6f7dd5b8082a7a.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38aac7c9e4f482be4a1ca5dbe4413377',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/0d9f86026cdef990f86c5a6670e3f9f6.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '027317e368fdeb93d7ba1e418e9ee4ef',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/d86733dccc79406cd51ae9572c6cbdeb.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '599e190938c599f87c8aed9287c59e88',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/b8c28632b16c52582e7383016ba1a016.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b15e6686be7f8eb3f165fe94f45dbce',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/7174c3a787157442e959ec7239757c82.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd895acfff396a1c6f518285dbd998f75',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/1de889a247d7fa66d4fb2e6e24225fd9.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be7e526f6104eff99cac630d63663356',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/88340f37d68c50c482beada80add8a93.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa886eb69f4aad46d61461676eee9f7d',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/14b76f78613da21dedff3550ffd84735.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '779add1bd89d5af49d8604c335b2d75c',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/5e8e56acc5f858f417d52f017b177079.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd609332eb964b031e0cf445b88f8f47',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/5613b9e3ab0f63b1cb88c55f2b2a0434.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dc8b0cf6066ffdcab5830e320ea0be9',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/cf3ec25f5aa0a4e1fa64c43f760793d7.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '930b919b1622a76103475265d44b9a20',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/b26da28c8e0cb70fe243890bf1110d89.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d8f50a612b920b0c79fa9a45ed14789',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/8a8fb1847917a34ae1531158a4405545.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29b2828ed0458b60e0b7d6d1292e0f90',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/734210bc3eadf10ea1ff67295321849a.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '364b90f0fa79829f5e1d72a25eb1cf5f',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/121e1986cc5cdeb024714e151514c0e9.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaaaf7661c72c299f06bbe3d7c73adda',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/530234e1a9fd96ca03d692b84de04ffd.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9ed4166841072f7f4275fe5e5d9d9aa',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/86097c68e840d218a96da563ce0aa302.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b9f110647ccd6e81ebea951534670e2',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/1a24827722237ab1f5adfbd9e2bde27c.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf5210caed39fc76958f4c6b01b1c682',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/36c8b9f7ac288104ad680ba84903c611.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44450d2b23449788ace81ba2c34f29d3',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/a21990889152a2d1d035549c150055c9.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '665d38b39481e49ffbb28f3e9d62589f',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/57999e8fb4976b78d8782f157af3db34.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eab1435c1f2f6b4e75032f28c9409334',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/9c96d4b99df05d3e609302d4ca997d24.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54c18c63ec63b5d5d5cf38b5f4b1fe50',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/7a0c01f227ee0339ab40b41d87a7d970.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '395ffe8ddba8819c8a5faf5f1c266d0a',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/3949d0843a667b29bc155967dbe746cc.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fefcfcb283dbde1ec7f48e71466e2be4',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/722de321b142569fa03039aa51152712.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f09b3cb5587215e2cee03dbb49e4b975',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/36f0eb4286bf75e62c5e0d1360c338d4.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa75750ab3e344d28354d5893b70d582',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/a54c1274c5b0f10be5778f99a5bc7d54.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcbe780160c12f86bc681a3262aae20c',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/9c395bea60524e1b7ac41694f48e3ec8.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dce083462ea5657bc5b217b2594474d0',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/55e37d433212a24904ebb61b7475495c.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca8e805d53bd20bec72bdd0ccb77b24',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/40846f52ebba6d00c8f8d4b2820b6030.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89dc8b3f7b10bc999bc181bc265f229b',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/0a437783ca6fb520ad6f4be8de8d61d5.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e1c1becc8f4ebb367f9d54f8cabaf5e',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/7c59f784b546e7e1947ccfb50d671f70.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94e27d8ea84b768e0c0833bbfa427457',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/a2bd02cc4acf5f5db154f1b945218beb.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77cb1d66f68f630d5ce42745de2750d0',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d4426320c551af94718688ced5eafaf9.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86834b88490ea42696e5f9581b442762',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/264dc573e9e529fd12a6ac90daf9125f.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c79543abd86192d1bea250ee5c022898',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/eb01e6a0d0d219d0d6fdacf2c355f739.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '483e1d1c174e61fc4c941741e383cc9a',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/7df7c3b3a06dfcd485d09ba832838f3f.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c04ce166bd05ef811ff30eaed755fc7',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/5bcb29264196f2d5729eeefeb640c616.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '735ba504b23ec259bb5c071e6c38d138',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/b528f74776800bd75863fe1cd535fc34.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d51505bee378f1be6353ff3234d5d8f',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/f26c679b4eb2d557c14e300617d3eee6.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45ca4ce28952e7d6956b56ea43102e48',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/6d622c5cf5ee12d047f0367f1d2b03c6.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d369d5d5cf924039462d436875379e3',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/473fc242fd186c1e9b189ae30ecae356.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a599f6bea04ead00fee1c19fde63f85',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/7e674c818773d0d0931d3381ff8b6726.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56062214d1fe9eaa9822a85de81f0b6f',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/1270e3f4c9e1c5dc95622204697571e4.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '526b4676c2c77eae6b4d9d7088d061a9',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/c3d1d0a608306d48ecad1f18d5866eb1.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9fdbe798b72c84bd5d04bfba2d750bb',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/7efa5796051f6445f237084d419d7f01.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0ff13d0787f198be3b8ae22b3016335',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/3a5273a2f7370c1d8619f7f6da52a55c.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fa5aee36767ddf08696a291b7f316b2',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/d0a71633ceecfd77d23cb2d0324e4443.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c738b913cb527fc55054f5ea0cd7a7',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/c6708bc05149aaab8f2cd54aee95bcfb.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d32f3f7f3630c0bc8f2b82a9ff4b47d',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/d502e3055ac4283075104b272305ace2.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7653efcac93a46c695d670e252bbe03c',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/33e4970813476a2fcec3dc464f1e6a1f.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69c9efb40c7f9319331f9a5071c48963',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/36e61a65ccb5f94bc035a748ec172c4c.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a759ce4f9a4558a9566dd538b76f0c2',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/e081e35182d39745c0ee1ba7116adc36.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd25d9f61e47306bed143e5febe8a8e8b',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/dad200491a4ee03250b7310a22306ff0.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '694a04faf34a8cc97f32e8102d9b1fa4',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/e25e3dac14948aba114c67a838b7fb41.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7d8d214c245e89c214edee1d034c7b3',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/bcee3449dd7f807af3c905acbc5e678e.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b94f5d78f6ac9c3533e7c37fa992ea17',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/0a259fa66652a9c6019fc3166ee50b4c.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '121dfd5fc1deb42c6449e6b700be6a4e',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/a9d7ed9fd1e871a5a82bcb002543e9f4.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b10536ae56007f6126421de17297627',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/56300c46eb5a63c18d7de3e451ad72c3.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fd820ca58a1590e0a8e19492607bc2b',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/147e532235d40c7ce3f8ea83d2da5838.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '013e676c595612d18247e9c0ee50e5a0',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/540ef4232961b7ec6a7d322daa2b2295.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4339065d251b9d32fd96518fa17116ec',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/6ee29b848b00a25679abf1941d9b5296.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd3c35af388cd0636e46913cf191e9ae',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/753f747685b2e0cedce9b79116b47fe9.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b1e6c8f0984e22eebf5782c779e4c2f',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/68dc3a1ba79ede5b38fbdf27c3dcca37.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '400156ed6b23a8946645296045083e85',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/582243d0b038be74b15d3de87c420623.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcad2c6e6cbbd1b478ed0460a96d269c',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/e0e671e2dfb92b828cc5a737eb67cd7c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61bf09d0fb48021d2423dd89b1934e1b',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/b89a8a635a2768c0a0273ab44a6ac7f5.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '773029a91b8deb92df733f413dfbf571',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/3b08484ad6e14d0aa7778728fe7f94b3.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c754c5c5f50fe0f56435e6f2e4520b2e',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/8f1b87d486c1f9f5bb1b957bd20d50ca.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b54bde3ff1fa0c2d48bcbc2f72f911be',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/90618a1587938759c779376d401c2850.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bb0b54fdb2fb48f1d49a1bfdca115cd',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/4cd838d6d87adf3cd0637812f6b2fd8e.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e60ffdeaf5aef843a7cb38f59506ad0',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/eec3040a5c76e91916596ab634af32ac.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96fd597b4ba1649d4d89527410af053e',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/488c9a8c674b590b7e8d0fb307fc24de.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37412afc52497555aa99c7c09ea47939',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/34210cc7fa31410aa3f52b379eb1a113.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdbdf7d88b8d06e460c2112f99496261',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/89879110b2988cc918732a63bcd2ce5e.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27acd19decee72de5e2dfdb02a62acf7',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/d8fdba584f89126560feb36b80d7f73a.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86e9dd38e3cfc1a77cae70116d914fdc',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/b068191650241ac132e02c36926694f0.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3363bb8952e86b9821fae130015248a0',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/e265949ba71feb454c49259e1102b610.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1295361e991b992b8f6fcac0cabf58',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/4080baff01692864967b7128526ea5e5.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba692a6035301bd7e8e65d9fe6ff18a4',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/c59930b3ceba19b885191a564267ee75.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c06c73e0bb12846436b4e521647a3d4e',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/7d2e0117b7ddc19ea57f36a2cace7174.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8478654b681458f971df6313ae05cec',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/ded3e7b61eac42b0de1c625e3afe9613.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0747b93cf0efeb25db67f336560fc2fd',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/5db1fac5ae07ae7860b261f67920985a.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c95ef743ae00be21ab69c89f8c37d51',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/491f0bb558e2802416dc870b492e31be.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6f564070b4d9fe3f46811f825e80f84',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/39cbe2e5b067e4b5dba6b79d63100d11.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '255aca761871094edf05309941d8a670',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/33bb5a5895c53358466a2d5860026982.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6da4328da44a4a1f1162b385f9baa9d',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/7c692ea76fb5c40830e9ab57e6ded903.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f8c635d90dc8cd7827dc20c7eae3cd',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/16d6b519b69bd0b4736d179d526714cd.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '058f4953fab8e613cda81e158b4250e3',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/0db283f91350e13d8fe7d062d59f3187.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19af4aa52e0696fb15e6ccdf0ff1d463',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/a4c5d47edd977e9beff56e4caeb6480c.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c008a6d6d38ba04b97d76e9fee20d1f0',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/64bd534760ba2eb4b4d3a4d2dcaecce0.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14f9f5ece0adf3b5758bead06676d25d',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/af5e134522fd83b981d6a44dc4157def.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96305ecd051b3d4131809fe2d0e8262e',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/8ddcc6c8537143cc34372104c478a38a.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '374f79bb2babd57c9d55406232f46a7f',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/c4795cb2d1bed9b10c3c359101ede868.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e08f9d36e635cc40ed4f57784b66a48',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/a3451ea7b3c64aa110dcc706063234d7.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd064ca01e19914df03cb5476f01de864',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/53bee0c3d65cc3d7e6861ae36f4193c5.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4b2887726eb62c161410b3e1241859f',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/c78e2882edf69e28e039c8101d2ea491.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d7d8f240c41012417a50e3fb5f0e613',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/3824afdeb3a010ab3e3a4c1a5cc36745.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5f7a0adf34fcc7ee486480baef0a3f2',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a9b67f7a5481bbf0dc73e1142121bc7b.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bb2e48ea6be88e8620e9696f2a17e2d',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/89c5b3cf657404183ecf14d17f8acb74.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1422e798cd65326b56f8c0d5c9c6ba6e',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/c13c53d8c44ab9e58d03825e6fb5c079.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bce1c05765d5bb42c57bc29f81a7ca82',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/ac1fccbc17f8a4251739671e2a201b89.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb2d80bfcd39b5ac001d8d018a7ee159',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/1023e8b35f89174c45d71739f0d48290.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e81490a55482b8f575d21aa4ceca5f35',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/1cbbe3256a52f6bbeb7ffa470a03d8bf.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e1a444704f9595ce0e6f1bac90c6645',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b83704ea1c7119c9e7de03c15724bf19.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433a986b6aaea206157a58357b3a4945',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/0a2e72809e285d3e687d5b96fe655967.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23127d194ca3fda749ad75636968c262',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/c1df8a2b64a51b1f6191d22c38751bf9.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '624d467ec5fd7705b2ae2e9d60dfebc1',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6c88371c33a20bc024ed4f1bf9404696.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9be66601e55790fdccbcf3fcde726abc',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/94dc78bbfa5eec4742289616f1583067.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2524730a3200438643b6f72eed2519c',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/9b2442af0554ccdfd72590223f396944.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae4b6a65f919d51d6edbda421d9a62b0',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/b92b292e314ee77ca1b08897e17b6fbb.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '819027781ecffafffd9410533c4bc7cb',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/c95a4faa03e096f7e2d32df10254fce3.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87f070a7643f6941fe1622d345a709e2',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/4c1171feea98caa21e3f5ef63c8f7815.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b89e73a5918d25929a47a34e6ed78ac',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/55e31db93bd269cce9c3688dff94fa3e.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3ed1736839e64821dd3d8eab2c21459',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9aff42befe14847eb2b3797eb4d49778.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45800f38969f948c0da04cf7553f5bce',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/552f657da980262fc7e386e356c1fe6d.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63af471a96bd1551332d3323a2336baa',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/8ba127a28801866121b406067e9e076d.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f593b669949d13b93d55167e4775ab2f',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/826b2ec24bde109119328b56d25d7802.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a882fa6d38d3e76d85f06a33435fb2c',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/f8fa31696701f7b9113107c02302a42f.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af2fb6a24effdd0979675124961720c',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/e193f802d934e5bd62dc9a3ee945d943.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea4904f91bfcd4fb07241d3f8d0e8f72',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/fd2a85f7c4ac0c2d1fa4354e5cdad0dc.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1872f5e8cb93294cb7d95bc0e51e4095',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/eb0a8da5a1b1984d2ffba34b169d62e7.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b563b02420c139bd72a1735974271f8',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/4491fddaba927bde7f42bb8d6cc1ad6c.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '959c9a38cd35b6c5c2b5391eff40654c',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/28e8611ecfcd71bd463b8dc26038f95e.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a405fd09c049c5c3ac270eaef2de06d1',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/f6db8c07e7076daa036c5b7b88c4b396.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2325b83e409642a2e65f6d132d4aa0b',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/b6fbdce353f874f22a61d8e13c24a0fe.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0b6fe886470c2521d4ea355676e9bff',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/2b5502187fc6944a69597d2c3a21afe4.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fab1368adcc776bdcaba4e276d043376',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/9e8324103912ef6bb3d7e92d6c147aaa.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '681ed69facc520259fe8e3ffa6879e40',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/a679c30b35fabd9841931a57d166b47d.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a135cb9472daf64f71c0ce5473ea92a6',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/8da622d132ac3cf1824bc95c6b5582da.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e31b84aca38ef0a669fe4793d3114ed7',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/aa50f0e6cc44d2d5bfe4851830208f2c.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f17f6a894523fcb53a2a71378485fcc',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/155aa51ab1944e1ab9f018d8c02b537d.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a1e55f0b7165a2b2c61fce3d4d7c28e',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/148a0695d295434fc10bbfd876c10e60.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3ef0627d6f2803d7d9c37cedcddbbea',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/f4ee52f565355938bb8bf11e54c21ae4.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c695de3281181e59fa2941c67b0b595b',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/92cce3b6bb1605c842952915161b9590.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3961be48c73b2c2c4e131ab1cd088fcd',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/4c582e9deadf1137334da28ac218c6c4.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '328539a334c4ee7a4a233a7eba421f4f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/b5bcaf6bf99d208ab88f7ac975026c98.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cbc8f8137b306ff09128cdfd798b1fb',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/b5ce2dc146f4ff16f10055327ab4ef14.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb34519ed44d9961da09ffd5f1f9e8ce',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/da34fe7829231f15ad4f3b006ac7c8a7.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5425d02e3f6ea1ad0c26a51bad9c3cc',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/deb798e94ce0d8ff3643597600c4e7a3.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3abb882ceb746b08221e5fb28e459184',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/2b2dc73739d7e6b3fd4d7fcd3e041726.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a79a133809d27df61be00ea39a9858bf',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/7ff04b0774e9871cc969d94928e26a93.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe0101fb70da12e9c790663b3da41db0',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/54d256c8c64bc3a63aa5dad1b3554678.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc08ac39ab602b1da8e4ee38d1d38412',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/fedeb940b0f310875dc982fda6ed7d9c.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a023f6d1fddfd86a3b2c8cc7832fe634',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/55a1d97bbc0322c2afd7165b4610ae53.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d37aa1df161443dd71479dd2a0dc8c1',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/73881f42c8b2ed004ff7c70421e4208b.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0915eeb695723fb9a3b5fef807ac3662',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/8d4f1f32bae96fda1452b28ae1cd6ef0.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afffe986a467f515c8e54dee6131b521',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/5a17ccc800c36ae496215c8c552bc86c.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eac8ead3264a170f0ee777b4864e4b4',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/eebb34c46e6546ffaf240df2cda7f578.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd0f9a8086a11348f13daccd6e651656',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/b918c98af08cd279f243fa557e9c7362.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2495be91f158f1b16af0ceb9ac583dd2',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/c09f47b6e76aba804c894edbc0bc6100.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '701399a532b44947f546ac00d28aade7',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/3717355a99a92d2703540defa3b7d012.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4020b6715b84ff931f9948c91b3eb07',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/fa150be820775a2b2a44e77036749983.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45fed621704606aefa8135fb11db15b9',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/a828e4e7924e820ac45c2fa202cb37ce.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9aeb4df7b04720932375f1f1fbaaa54',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/5d3efac4b16923cef343a9639458a134.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '577cf215fa780418d0975f27c14a984e',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/2cc4008f426c28012de79b245cb1563a.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfa9b4cdb297b1b3b08c33fb6c8f9d90',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/bcf5a0e58f61bb3713cb51f418c5e133.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739ea3acd46e7c8faae3828ab86d27fe',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/816f7783334a9e689f2f9eff89f53fcb.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f1f6832839218679bd268c530dc564e',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/0cd83d4ba1ce6ce87bebb5632b26c2d1.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266ac62a4d003227105bc2f1295a95ed',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/023fe1156123658d2706b03fc0dd7744.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c119bcada26081825fae7ce8f2fe639',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/de62f9b8a52adf93fb6b3b59fc20af67.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b416ff49f66effe69f4455e07186fbe6',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/dbfd2d2ef58dc63049800e3ab6639db0.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8d171afabdb880ce160e8878776418d',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/a984b07e4a82af9a93933114cef4c70f.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '108491ff7380179fe48687a27708f826',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/cc41e485e0dc29231373424154c7e983.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fe72e1ec0a23d58bda48d4b948a6322',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/8d4148eea7f7fed6058c7b2979eabb67.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '924bc5ecacb9a4f27d4935738b901bca',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/c70e59b54337466f3925d2ba64133a54.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23b663f15793473a99372429f529b90d',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/18ac63ad78dd0ca9f505803667a5b346.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc5c965a1dacbb8a06267d4293e70cc1',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/57241bd11056b35564add6d3c5cdfda9.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4624a5a06cc9e960787c9864a6a0d60',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/da69bc62fefde88d122d780723651c0c.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f27c2c44e8b8133c34063b0388a3d8bc',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/197ad20600b01c927a229433ac90a9ae.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b31bb85d9dfc35382e8c42f53fb700',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/e0ea8c2d96ecb999215461b54f23ec33.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebf3ff0701d03d0e8f72995eeea29dd0',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/849b43c343ab708537d7d44845fb086d.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e84d594b27388c41c7db2199093cf15d',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/fff21de3ff4de995c88a3fab75654503.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1552c37324126ea828f5d14bcabc5f51',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/5b0666a5296facc316bf3c516081c1b8.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c41412ad9a19e648036aaa7901b37dd',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/28979e10c9282f935ab60e176ebaba93.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa60d513805caab84852ce8b18ec5536',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/fe587fa972220bf6c0dd1ffa48ad7f24.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac0f2c23355a7d2cca967cf4cd8d1e49',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/fef6783af0f4adcd3a5583ca6d290dee.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbb813004a93be444a508a0df7768248',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/90d1dbcdd9717f589bb027fc86a4fcfc.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96af07397fc9fb89059fd91fdc5ae20e',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/a4098bde539acfcd0e40dc73c1df68c4.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d63dccd4ced958c50b6e9a0833adcd0',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/732db4d66fa1245c5135a8c44d2b658c.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9cb92daecdebb93a1949a27798cffcf',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/634ec908174b13025e70a170bd198f81.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6489fdb29a8e29a1befb7e1bbf485fe',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/350dd8ce4a0563b5c7fae9c72a81825c.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76337e9be7314570e8ce57b8cc42cb40',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/1fc8622a4bd427738dd31b4a97edd8ca.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '657c609e311dc72c92d3856d6eb525c8',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/fe23f72cde0acc5968eb91ad266847cf.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d66ab3cf6c353ffafff1c4617b10ab6',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/e27c51b11ba7eadfe84df7f284f34b66.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba7c8591fe728e9ae628b507bf5f0ab6',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/337bd94ab1b9bba9825ff260b6365244.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cbd2adab385ce15c6d56a4a628b8a23',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/bc4411aa1aab029e4d3a9c033f5ba836.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d11eeeb062dc138307081697bce05dd',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/de0f2d44f1c1acc75ae71ac922f4c6ec.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c45e789a94eca4afd30f773f5aa126ad',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/bc0a12c5e2f3328fc00b7996599781e2.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '017229ac17088f0ef39dacbdf2dbc10f',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/63082509212eb02ddd86e254d4b02800.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9052796e6edf5cbd1d246188db9df324',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/92faed5dec13ee1eedb9861037fa83f4.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1472c20be825ef4e4276706fddcca0b',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/c9573fb4aad204caed8f6e0ddcdfad68.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98c7e45bb1a035bdfe221616d024feaa',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/822f93c7503d9f426241ff8771b62954.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63affa0e29c977253aac90907f17295d',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ad375f1d5ac4eab56521357fa088bac2.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd02c3fb35c73b6dc4a59d047e1613e38',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/ab4a3bfb9ea44008c8a88a25302f1905.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286d3e510010b74e3c016157b20b277a',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/81e888b993596ba2d17cc5011857f30f.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '912a32446e9aff36de394f2a493f0312',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/80a5548322bc488dbbcb9344cb97dbca.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32b6522dea920cf3159c08f7a4825609',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/459813675bd2c2009bb58788bbbf5c84.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b260ad6511be6791c539dad58d001ea',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/534cc6e79fdfba89927b36366b81531c.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eaad819eee5fba9c9919e00f08b3d79',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/9190f9aa5930289209b559e2d56ff910.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a99b929a3edd3351deb6aa9a9abb004',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/333875806e2dfbaf667a7d23a277564c.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dc8f20b4dafa26101f498c3b8d6f59f',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/fd3145212003b919466fcdffc90b6bc7.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d2a884de22ca836bbc8715af3cca244',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/4ff24bd76df7a9b900083e103d0e4df5.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ddc6a705265a1433edc5cfa24a609d0',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/93ff1562600be9cec67d727a21e2b774.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8bb3d57812dbbfc3ce7c578e06a3576',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/92e044a71a650e40c3cb4a4f189c5445.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cfdeeea2379e31068609786ac34894f',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/8430b1b818caac47b29d0b9528dcd075.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33dec73c7828a552595674b411e9aedd',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/40b3e8b3ef1159947a58186ccb79151e.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56bb8a7de158a42dd9e40acc64def928',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/cefd805886add8c13aeacebcb9e849ac.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e05d22e691a7397063e57f2584ff36e9',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/bf3c52ffaad94dedc317bafaffa26337.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ee3b6e3b457dd76416f821415395e3',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/67f4c3b11c3b591739f34b848e1fcbd1.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b0becbbb450e18b74646b322c70722c',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/e07706d121939af7d6701ca638138651.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3233f4156c3cdbc2e4da870aa99ebbf6',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/4ce85d2ad27a2edcda3a5f64252241d0.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ed7c18ac9817bca187ceacaa0d2dcef',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/2a039e95f0b52327ae9999c4ac82a80d.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce33d2cc13611dd960ef3ab8c0842f3b',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/b4d25bee6366959dc67a20d7ad854c9a.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b023f98a866bcc9766233ad9f8190ad1',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/2e5af514df04ac59f78ba3acf0f9c688.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '848bffe386566ff5a45bf619b2038aeb',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/24139fc9c4cbf77e29b4472daa80320c.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bd632a61f87f7e14244cc4c9ea2ac50',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/329d546f2fc0b3f18be16fb2158949d2.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a6e5a456b8dc54da47f55a47e19b6d7',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/3d2f594e26f567b7c7cad2ff7d490c75.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77a1efda3d08d8f32c8d912d90d9294e',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5e2dbed23484628b3a494004dfdcf651.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca5bfe7d0752e7db1fb25823b100f4cb',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/8d0ade3c8cda19ec3da42c56bec625cd.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3a8cce21ca43e11a83fbb100d67093a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/e58adccb442e63124eb04a266b2357bd.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '424edd19064ea133dbdcb3dfaaac5d1a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/5c493fef903ab4cf09cce35199426da9.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a44dc1819e82dfc0dffb019b8f01375d',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/d79700fb09b441c21bae123636a943c1.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c70aa0fb075244199312a89d0f3439ba',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/238bbc5ccf0560049d56b06670b8fcbd.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '145239a30335f8c00e796911264317d1',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/ab5dd0c570847b2481e70a61f02d86ac.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e3abf5f07df12d892dccee0d113993b',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/16b9a592f0d36d88504d66e43a2d73e7.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6cb888458fc3d4df2e07354d4df78d0',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/538ec4701805ebb34a8d779bf9241275.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1c5640c15af14da2c3dc066a684d3b7',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/f3fabbaaa5f7ea52783ce3a013e8a5ca.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '706283508df7d6e2d8d2f18e3e1ab45d',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/9113fa1fbad653050cdb80a4bd2fde56.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9d754703c3da7d6a20a709c13e5d7b5',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/4f4371a3170fb2c4f48141f1ebf4e5d5.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd81e6b04764e9836558fc2775dee79b',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/868e7175e7dc8aa1fccc2d8b1b275c88.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9c1077fda3414d19ec45d507b9aeb77',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/9ded6ad1a56f8664fc3aa92156fe6894.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f3db2447ef94d42b5212b04c2e4b766',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/95aa7f99853ed95cf2fd65991c436c40.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c8a56e86c250bb095a4be6a74352141',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/146ffa4c19d1cee578b55da6d694b48f.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe742e2a52d00f762145aa2dbea4da94',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/a179fb2861a6d3dd8ab5b53d074cdc54.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38e39ae2aa64b3ad12a2ae90757a78ce',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/9f2b7451e1d1b6fb1ae5c332761de57b.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2bf07cfc8568ea4716c9177f2935fbe',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/44dfde4868590a3d3c9c0c166ce5f657.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffbb256756b2f4b0c78104a2bf62e8ab',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/2311c0efd5da09f65c69a235d57a3a2a.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba084f479f350432a01a8b31bfd74822',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/d5b05a1ec1a79165a3013bd933e0f399.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5f6043909e512506ecd1c4d9b2dd482',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/3c45eed1838693910be117919e1a07fc.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '123c062583e3a78f1b8a7650df139d40',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/533392243107cfee762174506a6dfb92.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'c394f5af2474fbff115a7ae7f767a814',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/a929635e72f69c74fb2c399bb324386b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '755142add8add27284bc31cd7142dd50',
      'native_key' => 1,
      'filename' => 'modUserGroup/6b41093967631e7e4da7aaa68a6f33b6.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'f140079c8afb7fa280f4e4097bae7afc',
      'native_key' => 1,
      'filename' => 'modDashboard/b64066161a6b7ea5c1237ae8b0fe372f.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '12585f63cfbf07511fead944e6572c51',
      'native_key' => 1,
      'filename' => 'modMediaSource/4a15b351d2fdd1f42ef56a487024b478.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6da7b22483ba3b130ca5764dce4a8990',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/1f97e4f8d25185f299293292695b7292.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4b5b3ea0c58ed2b59330c2a9b8a4f6cb',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fe4fe40bd9b81cd5df16a4a1fce1f743.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f5f389153786b19355b14bad98f36335',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/338455a5115f6eeb089f6c4257a2bede.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9a5777ed0ca39a0040b7d0302bd10df5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7801bed8ff51bf3ce30dfc5b15c1236d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '34539073058b2ffbcd0917b45c8a0402',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/521d84bb2cd285ae57b643bafb318365.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'ee518e7aeb9fa434dadb82aa643f14fb',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/850fd2895f6a884f5b08e07f3352d5c0.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '4617a03f97196b045cb28742e45689b2',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/c1aa9c94d867e4a97f689ac6f8dc4823.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fbe221e75d89e28f50eb8327b9d52703',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f6c79942ef99bbeecb374097257ea2b5.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '864f216a2087f11714dd13c4040a9768',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/fe54e508b6b10b8910365d21bd972389.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ea642a49910424965ec34814516c1966',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/24fb1d6e7f21d720bb2da901230af84d.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bc30b3fdc9d04af857ecd5d0c0d0d55c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/13fe9eaf031b93f79449aad4b63fe3fe.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fcd38508eea668ae5b4df447de62139e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9906ca27af421cc0bb07a188a9c304f8.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '74a183c02d9063f08d671e2de1ea88da',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/52c1aae5f9b6bac34ca28d1f45b92e4d.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a8d0d60d2977105114d30f82eb67398d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e838373fd019ed08b51861f0831079e9.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '03784c7819777752467f8d6abd479b70',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bcbea085c642416c9b9f35f67ec1fcdf.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e85d58e3b2bdf9addd3211930b5f44a9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e01f4963e90b2b32426b49d1cabdb704.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9b6df2a7d4cb07a826f2307eb718c41b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/35ebe488418aac2cd1f834286d0e65b9.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '578da0d5a2393c4037679ebc0b752b41',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ec0b7d09a70b2eb31f3cc0a5026b49ba.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a33750f767ec6d775462e4516a988b9c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8167e400715446d10997d68d3a901570.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3ac01337f0bb1afa2afc446de0ea5825',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/42e96da9e4b0dfbcc54c4037d0e4b54f.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1fd2d8b70674af92be035a2ab0e4da5d',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/ece5a08e1122d13a963ab0156ddad6bf.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0545ae2103fd43b84c607f49b39a5ea5',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/4c6c26633e8922a4ddd07dd847583ae0.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'eb859671562b2170c4c372d353d99bf3',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/f438ac22dd6c84ee35a797987e4661d8.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd9fc2321e6e7c3045bad3465a135f98f',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/710bc80781595fae7b6c41bf5a29fd2a.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '929b98ecd0299c096ef5884bdb043675',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/d5a9c80c029d3403afb7080dc076916c.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f3f8c9167e6f1b5c9de3fd06a4a673ae',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/1a2760c8a9be18524c064ceaa93a04bc.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ce99a09da42b2754e4db0112d7266081',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/a6e93f3845c25ddef651831f395c4631.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e126ae0bf2694e907e93001775a274a9',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/e3deeb90fb0a55a6ea55f9f61a0f93e0.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '99ec4847bef8dd32c0454d70cf03107e',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/72d7491b5b7c6e52ae48a0aa71f3c8f8.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1c90a82f069ecac22d00ad43dba341a9',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/8161dfd5d01a7e8648e1319d54eef990.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e7134046cbb471f7d28ef670a977d8c1',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/82cf12cd89f6e630ed2628fabcd626e3.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '39597a29d8db41f3b6c0faed3120337a',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/c6e4612c2968677c2af6420b590de9a7.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '26d289340c4ea5816358644ae3045565',
      'native_key' => 'web',
      'filename' => 'modContext/09a091d0aff32ee0a9ae2ca01d01d85c.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '67cb38e2c3f40ce95d8f9e2d1a9d11d1',
      'native_key' => 'mgr',
      'filename' => 'modContext/bcd874e2c685e6fd4fec9af7174cd618.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd6304769d64a01382835bae2a98cfa13',
      'native_key' => 'd6304769d64a01382835bae2a98cfa13',
      'filename' => 'xPDOFileVehicle/2b4a9dc0c4ed23cc5f547e741f40fbbd.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ffa2e2a623a0d074fee97a1073fd9e85',
      'native_key' => 'ffa2e2a623a0d074fee97a1073fd9e85',
      'filename' => 'xPDOFileVehicle/b982e78273bfc9d8c4a61bf4bab507f0.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f648e7a5a2c5e5f586af87786dc99592',
      'native_key' => 'f648e7a5a2c5e5f586af87786dc99592',
      'filename' => 'xPDOFileVehicle/725190f61150cb5698ce511c049588d8.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e8b71782494c6f41dffd13b49fc29695',
      'native_key' => 'e8b71782494c6f41dffd13b49fc29695',
      'filename' => 'xPDOFileVehicle/0f29f3899a75cde9b682b7fca01ffdf2.vehicle',
    ),
  ),
);