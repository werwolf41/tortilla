
Canonical


Author: Bob Ray <http://bobsguides.com>
Copyright 2010-2014

The Canonical snippet puts a canonical tag in the &lt;head&gt; section of your template. It executes only for Symlinks so that for SEO purposes, you won't be penalized for duplicate content.

Put the following tag in the &lt;head&gt; section of all templates:

[[!Canonical]

Official Documentation: http://bobsguides.com/canonical-tutorial.html

Bugs and Feature Requests: https://github.com:BobRay/Canonical

Questions: http://forums.modx.com

Created by MyComponent
